<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home.twig */
class __TwigTemplate_3377b9bddd83dc3ffd4433445ba14266 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'additional_head' => [$this, 'block_additional_head'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.twig", "home.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Home - TinyCMS";
    }

    // line 5
    public function block_additional_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css\" />
";
    }

    // line 9
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 10
        echo "    ";
        if (twig_get_attribute($this->env, $this->source, ($context["session"] ?? null), "success_message", [], "any", true, true, false, 10)) {
            // line 11
            echo "        <div class=\"text-center\">
            <div class=\"alert alert-dismissible alert-success\">
                <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\"></button>
                <strong>Well done!</strong> ";
            // line 14
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["session"] ?? null), "success_message", [], "any", false, false, false, 14), "html", null, true);
            echo "
            </div>
        </div>
    ";
        }
        // line 18
        echo "
    ";
        // line 19
        if (twig_get_attribute($this->env, $this->source, ($context["session"] ?? null), "error", [], "any", true, true, false, 19)) {
            // line 20
            echo "        <div class=\"text-center\">
            <div class=\"alert alert-dismissible alert-danger\">
                <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\"></button>
                <strong>Hey there!</strong> ";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["session"] ?? null), "error", [], "any", false, false, false, 23), "html", null, true);
            echo "
            </div>
        </div>
    ";
        }
        // line 27
        echo "
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12 mx-auto\">
                <h2 class=\"title\">
                    <i class=\"fas fa-newspaper\" style=\"color: var(--title-tex); font-size: 25px; margin-right: 0.2rem;\"></i>
                    Latest News
                </h2>
                <div class=\"row\">
                    ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_array_batch(($context["latestNews"] ?? null), 3));
        foreach ($context['_seq'] as $context["_key"] => $context["news"]) {
            // line 37
            echo "                        <div class=\"row\">
                            ";
            // line 38
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["news"]);
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 39
                echo "                                <div class=\"col-md-4 mb-2\">
                                    <div class=\"card custom-card\">
                                        ";
                // line 41
                if (twig_get_attribute($this->env, $this->source, $context["item"], "thumbnail", [], "any", false, false, false, 41)) {
                    // line 42
                    echo "                                            <div class=\"card-thumbnail\">
                                                <img src=\"";
                    // line 43
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "thumbnail", [], "any", false, false, false, 43), "html", null, true);
                    echo "\" class=\"card-img-top\" alt=\"...\">
                                            </div>
                                        ";
                }
                // line 46
                echo "                                        <div class=\"card-body custom-card-body d-flex justify-content-between\">
                                            <div style=\"width:100%;\">
                                                <h5 class=\"card-title custom-card-title text-center\">";
                // line 48
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 48), "html", null, true);
                echo "</h5>
                                                <hr style=\"border-color: white; margin: 10px 0;\">
                                                <div class=\"card-body\">
                                                    <p class=\"card-text\" style=\"color: white;\">";
                // line 51
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "content", [], "any", false, false, false, 51), "html", null, true);
                echo "</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 58
            echo "                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['news'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 60
        echo "                </div>
            </div>
        </div>
    </div>

    <div class=\"howto-section\">
        <div class=\"text-center title-connect\">HOW TO CONNECT</div>
        <p class=\"text-center realmlist\">set realmlist logon.tinycms.com</p>
        <p class=\"text-center\">
            <a class=\"howto-links\" href=\"#\">Download Client</a>
            <span style=\"color:white;font-size:23px;\">|</span>
            <a class=\"howto-links\" href=\"#\">Connection Guide</a>
        </p>
        <p>";
        // line 73
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["server"] ?? null), "get_realm_name", [], "method", false, false, false, 73), "html", null, true);
        echo "</p>
    </div>

    <div class=\"server-status\" style=\"padding: 20px;\">
        <p class=\"title text-center\" style=\"font-size: 22px;\">
            <i class=\"fas fa-server\" style=\"top: -3px; position: relative; right: 5px; margin-right: 10px;\"></i>
            Server Status
        </p>
    </div>

    <div class=\"server-status-inner mx-auto\" style=\"padding: 20px;\">
        <div class=\"card-title custom-card-title text-center\" style=\"margin-bottom: 20px; font-size:22px;\">
            <img src=\"/tinycms/assets/images/wotlk.png\" style=\"width:25px; margin-right: 10px;\" alt=\"\">
            <span>";
        // line 86
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["server"] ?? null), "get_realm_name", [], "method", false, false, false, 86), "html", null, true);
        echo "</span>
        </div>
        <p class=\"text-center\" style=\"font-size: 18px;\">
            <i class=\"fas fa-exclamation-circle\" style=\"font-size: 1.5em; margin-right: 10px;\"></i>
            Currently the realm is <span style=\"text-transform:uppercase; font-weight: bold;\">Online</span>
        </p>
    </div>

    <div class=\"community-section\">
        <div class=\"community-title text-center\">become a part of the community</div>
        <div class=\"discord-widget text-center\">
            <a href=\"#\">
                <img src=\"https://discordapp.com/api/guilds/938237660017872896/widget.png?style=banner2\">
            </a>
        </div>
        <div class=\"community-text text-center\">
            Join our <a href=\"#\" style=\"color:var(--title-text);\">Discord</a> or <a href=\"#\" style=\"color:var(--title-text);\">Community Forum.</a><br />
            Remember to familiarize yourself with our <a href=\"#\" style=\"color:var(--title-text);\">Rules & Regulations.</a><br />
            Thank you!
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "home.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  198 => 86,  182 => 73,  167 => 60,  160 => 58,  147 => 51,  141 => 48,  137 => 46,  131 => 43,  128 => 42,  126 => 41,  122 => 39,  118 => 38,  115 => 37,  111 => 36,  100 => 27,  93 => 23,  88 => 20,  86 => 19,  83 => 18,  76 => 14,  71 => 11,  68 => 10,  64 => 9,  59 => 6,  55 => 5,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "home.twig", "D:\\xampp\\htdocs\\templates\\default\\home.twig");
    }
}
