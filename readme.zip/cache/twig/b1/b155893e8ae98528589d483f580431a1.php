<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.twig */
class __TwigTemplate_e1539ff9571aab555a97985641c3cd84 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'additional_head' => [$this, 'block_additional_head'],
            'content' => [$this, 'block_content'],
            'additional_scripts' => [$this, 'block_additional_scripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\" />
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
    <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ\" crossorigin=\"anonymous\" />
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css\" />
    <link rel=\"stylesheet\" href=\"assets/css/style.css\" />
    <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">
    <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>
    <link href=\"https://fonts.googleapis.com/css2?family=Roboto&display=swap\" rel=\"stylesheet\">
    ";
        // line 14
        $this->displayBlock('additional_head', $context, $blocks);
        // line 15
        echo "</head>
<body>
    <!-- Navbar Start -->
    <nav class=\"navbar navbar-expand-lg navbar-dark\">
        <a href=\"/home\">
            <div class=\"logo\"></div>
        </a>
        <div class=\"userbar\">
        ";
        // line 23
        if ( !twig_get_attribute($this->env, $this->source, ($context["session"] ?? null), "username", [], "any", true, true, false, 23)) {
            // line 24
            echo "            <li class=\"nav-item\">
                <a class=\"nav-link\" href=\"/login\">Login</a>
            </li>
            <li class=\"nav-item\">
                <a class=\"nav-link\" href=\"/register\">Register</a>
            </li>
        ";
        } else {
            // line 31
            echo "            <li class=\"nav-item\">
                <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"userDropdown\" role=\"button\">
                    ";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["session"] ?? null), "username", [], "any", false, false, false, 33), "html", null, true);
            echo "
                </a>
                <div class=\"dropdown-menu\" aria-labelledby=\"userDropdown\" id=\"userDropdownMenu\">
                    <a class=\"dropdown-item\" href=\"/account\">Account</a>
                    <a class=\"dropdown-item\" href=\"/logout\">Logout</a>
                </div>
            </li>
        ";
        }
        // line 41
        echo "        </div>
        <div class=\"container\">
            <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarNav\" aria-controls=\"navbarNav\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
                <span class=\"navbar-toggler-icon\"></span>
            </button>
            <div class=\"collapse navbar-collapse\" id=\"navbarNav\">
                <ul class=\"navbar-nav mx-auto\">
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"/home\">
                        <i class=\"fas fa-home\"></i> Home</a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"#\">
                        <i class=\"fas fa-link\"></i> How To Connect
                        </a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"/store\">
                        <i class=\"fas fa-store\"></i> Store
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->

    <!-- Banner Starts -->
    <img src=\"assets/images/banner.jpg\" alt=\"\" class=\"banner\" />
    <!-- Banner Ends-->

    <!-- Content Starts -->
    <main>
        ";
        // line 74
        $this->displayBlock('content', $context, $blocks);
        // line 75
        echo "    </main>
    <!-- Content Ends -->

    <footer class=\"footer\">
        <div class=\"container\">
            <div class=\"footer-title text-center\">
                Connect with us
            </div>
            <div class=\"footer-social\">
                <a href=\"#\" target=\"_blank\" class=\"social-icons\"><i class=\"fab fa-facebook-f\"></i></a>
                <a href=\"#\" target=\"_blank\" class=\"social-icons\"><i class=\"fab fa-twitter\"></i></a>
                <a href=\"#\" target=\"_blank\" class=\"social-icons\"><i class=\"fab fa-youtube\"></i></a>
            </div>
            <div class=\"footer-copy\">
                <p>Proudly powered by: <a href=\"https://github.com/PrivateDonut/TinyCMS\" style=\"color: var(--title-text);\">TinyCMS</a></p>
                <p>&copy; ";
        // line 90
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " TinyCMS. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src=\"https://code.jquery.com/jquery-3.5.1.slim.min.js\"></script>
    <script src=\"https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js\"></script>
    <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-qr6s LL7alrTT0mso5C5PL09dww1cmGhyu/wVa+6h9hV6Z9ABnFsIa3C5V4PEmyxL\" crossorigin=\"anonymous\"></script>
    <script src=\"assets/js/custom.js\"></script>
    <script>
        \$(document).ready(function() {
            \$('.dropdown-toggle').dropdown();
        });
    </script>
    ";
        // line 104
        $this->displayBlock('additional_scripts', $context, $blocks);
        // line 105
        echo "</body>
</html>";
    }

    // line 7
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "TinyCMS Theme";
    }

    // line 14
    public function block_additional_head($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 74
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 104
    public function block_additional_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "base.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  194 => 104,  188 => 74,  182 => 14,  175 => 7,  170 => 105,  168 => 104,  151 => 90,  134 => 75,  132 => 74,  97 => 41,  86 => 33,  82 => 31,  73 => 24,  71 => 23,  61 => 15,  59 => 14,  49 => 7,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "base.twig", "D:\\xampp\\htdocs\\templates\\default\\base.twig");
    }
}
