<?php

class Configuration {
    private $config;

    public function __construct() {
        $this->config = [
            'db' => [
                'auth' => [
                    'database_type' => 'mysql',
                    'database_name' => 'auth',
                    'server' => 'mysql.cloudnest.me',
                    'username' => 'privatedonut',
                    'password' => 'ascent',
                    'charset' => 'utf8mb4',
                    'collation' => 'utf8mb4_unicode_ci',
                    'port' => 3306
                ],
                'website' => [
                    'database_type' => 'mysql',
                    'database_name' => 'website',
                    'server' => 'mysql.cloudnest.me',
                    'username' => 'privatedonut',
                    'password' => 'ascent',
                    'charset' => 'utf8mb4',
                    'collation' => 'utf8mb4_unicode_ci',
                    'port' => 3306
                ],
                'characters' => [
                    'database_type' => 'mysql',
                    'database_name' => 'characters',
                    'server' => 'mysql.cloudnest.me',
                    'username' => 'privatedonut',
                    'password' => 'ascent',
                    'charset' => 'utf8mb4',
                    'collation' => 'utf8mb4_unicode_ci',
                    'port' => 3306
                ]
            ],
            'soap' => [
                'username' => 'admin',
                'password' => 'admin'
            ]
        ];
    }

    public function get_config($key) {
        if (isset($this->config[$key])) {
            return $this->config[$key];
        } else {
            throw new Exception("Configuration key '$key' not found.");
        }
    }
}